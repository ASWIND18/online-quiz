export const instructionsData = {
  title: "Quiz Instructions",
  data: [
    "There are four questions in this quiz.",
    "For each question, you will be provided with four options.",
    "You can only select one option per question.",
    "Once you select an option, click the 'Next' button to proceed to the next question."
  ]
};
